window.onload = function () {
    var messageFeed = document.getElementById("message-feed");
    
    function wScroll(){
        console.log(messageFeed.scrollTop);      
        messageHeight = messageFeed.offsetHeight; 
		
        var heightToScroll = (130);
        var header = document.getElementById('header');
    
        if(messageFeed.scrollTop > heightToScroll){
            header.className = "header header-scrolled"
            messageFeed.className = "message-feed message-feed-scrolled"
        }
        else if(messageFeed.scrollTop < 1){
            header.className = "header header-unscrolled"
            messageFeed.className = "message-feed"
        }
     };   
    messageFeed.addEventListener("scroll", wScroll, false);
    wScroll();
            
    function logMessage(event){
        
        //get time
        function addZero(i){
            if(i < 10){
                i = "0" + i    
            }
            return i;
        }
        var d = new Date();    
        var h = addZero(d.getHours());
        var m = addZero(d.getMinutes()); 
 
        //build message
        function appendMessage() {
            $('#message-feed').append(
                '<div class="message message-to"><div class="message-body"><p><b>' + messageVal + '</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
            );
        }
      
        //set event trigger       
        var messageInput = document.getElementById("message-input");
        var messageVal = messageInput.value;
   
        //hipsum responses
        var responseTimed;
        
        function timedResponse(){
            setTimeout(
            function appendResponse() {
                var randNumber = Math.floor((Math.random()*10)+1)
                switch(randNumber){
                    case 1:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>What is your name?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 2:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>How may I help you?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 3:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>Can you please disclose some valuable information like Employee Id?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 4:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>Can you be a little specific on what </br> information you want?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 5:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>If you need any further <br/> clarifications, please contact Infosys toll free number - 1800 22 5522</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 6:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>Are you an Infosys Employee?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                    case 7:
                        $('#message-feed').append(
                            '<div class="message message-from"><div class="message-body"><p><b>Do you work for Infosys?</b></p></div><div class="message-timestamp"><p>Today ' + h + ' : ' + m + '</p></div>'   
                        );
                        break;
                }
                messageFeed.scrollTop = messageFeed.scrollHeight;
            }, 2000);
        };
		
		// fire on ENTER key
        if (event.keyCode == 13) {
            event.preventDefault();
            messageInput.value= "";
            appendMessage();
            messageFeed.scrollTop = messageFeed.scrollHeight;
            timedResponse();
        }        
    };
	
    document.addEventListener("keypress", logMessage, false);
}

function insertMessage() {
  msg = $('.message-input').val();
  if ($.trim(msg) == '') {
    return false;
  
  }
  
  $('<div class="message message-personal">' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
  setDate();
  $('.message-input').val(null);
  updateScrollbar();
  setTimeout(function() {
      
    fakeMessage(msg);
  }, 1000 + (Math.random() * 20) * 100);
}


function fakeMessage(msg) {
  if ($('.message-input').val() != '') {
    return false;
  }
  $('<div class="message loading new"><figure class="avatar"><img src="https://lh3.googleusercontent.com/-ESde32tGDcQ/AAAAAAAAAAI/AAAAAAAAAbM/mGS65MIkoQs/s0-c-k-no-ns/photo.jpg" /></figure><span></span></div>').appendTo($('.mCSB_container'));
  updateScrollbar();

  setTimeout(function() {
    $('.message.loading').remove();
  
    $('<div class="message new"><figure class="avatar"><img src="https://lh3.googleusercontent.com/-ESde32tGDcQ/AAAAAAAAAAI/AAAAAAAAAbM/mGS65MIkoQs/s0-c-k-no-ns/photo.jpg" /></figure>' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
    setDate();
    updateScrollbar();
    i++;
  }, 1000 + (Math.random() * 20) * 100);

}

$('.button').click(function(){
  $('.menu .items span').toggleClass('active');
   $('.menu .button').toggleClass('active');
});